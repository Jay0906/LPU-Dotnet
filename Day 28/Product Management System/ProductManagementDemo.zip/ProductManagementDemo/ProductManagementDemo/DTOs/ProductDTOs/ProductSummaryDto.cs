﻿namespace ProductManagementDemo.DTOs.ProductDTOs
{
    public class ProductSummaryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
