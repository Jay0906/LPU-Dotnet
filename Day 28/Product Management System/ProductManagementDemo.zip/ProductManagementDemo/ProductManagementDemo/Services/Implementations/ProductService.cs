﻿using Microsoft.EntityFrameworkCore;
using ProductManagementDemo.API.Entities;
using ProductManagementDemo.DTOs.ProductDTOs;
using ProductManagementDemo.Services.Interfaces;
using ProductManagementDemo.API.Data;

namespace ProductManagementDemo.Services.Implementations
{
    public class ProductService : IProductService
    {
        private readonly AppDbContext _context;

        public ProductService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<ProductSummaryDto>> GetAllProductsAsync()
        {
            var products = await _context.Products.ToListAsync();

            return products.Select(p => new ProductSummaryDto
            {
                Id = p.Id,
                Name = p.Name,
                Price = p.Price
            }).ToList();
        }

        public async Task<ProductSummaryDto> CreateProductAsync(CreateProductDto dto)
        {
            var product = new Product
            {
                Name = dto.Name,
                Description = dto.Description,
                Price = dto.Price,
                CategoryId = dto.CategoryId,
                CreatedAt = DateTime.UtcNow
            };

            _context.Products.Add(product);

            await _context.SaveChangesAsync();

            return new ProductSummaryDto
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price
            };
        }
    }
}