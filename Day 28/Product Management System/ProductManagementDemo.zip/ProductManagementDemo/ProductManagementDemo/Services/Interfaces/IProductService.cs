﻿using ProductManagementDemo.DTOs.ProductDTOs;

namespace ProductManagementDemo.Services.Interfaces
{
    public interface IProductService
    {
        Task<List<ProductSummaryDto>> GetAllProductsAsync();
        Task<ProductSummaryDto> CreateProductAsync(CreateProductDto dto);
    }
}
