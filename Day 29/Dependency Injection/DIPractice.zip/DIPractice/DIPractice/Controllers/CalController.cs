﻿using DIPractice.Serivces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DIPractice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalController : ControllerBase
    {
        private readonly ICalculatorService _service;
        public CalController(ICalculatorService service)
        {
            _service = service;
        }

        [HttpGet("add")]
        public int Get(int a, int b)
        {
            return _service.Add(a, b);
        }
    }
}
