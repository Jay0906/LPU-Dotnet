﻿using DIPractice.Serivces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DIPractice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GreetingController : ControllerBase
    {
        private readonly IGreetingService _service;
        public GreetingController(IGreetingService service)
        {
            _service = service;
        }

        [HttpGet]
        public string Get()
        {
            return _service.GetMessage();
        }

        [HttpGet("test")]
        public string Test()
        {
            return "Controller Working";
        }
    }
}
