﻿using DIPractice.Serivces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.ExceptionServices;

namespace DIPractice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly GuidService _service1;
        private readonly GuidService _service2;

        public TestController(GuidService service1, GuidService service2)
        {
            _service1=service1;
            _service2=service2; 
        }

        [HttpGet]
        public object Get()
        {
            return new
            {
                First = _service1.Id,
                Second = _service2.Id
            };
        }
    }
}
