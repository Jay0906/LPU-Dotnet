﻿namespace DIPractice.Serivces
{
    public class FormalGreetingService : IGreetingService
    {
        public string GetMessage()
        {
            return "Good Morning, Message recieved";
        }
    }
}
