﻿namespace DIPractice.Serivces
{
    public class GreetingService : IGreetingService
    {
        public string GetMessage()
        {
            return "Message Recieved";
        }
    }
}
