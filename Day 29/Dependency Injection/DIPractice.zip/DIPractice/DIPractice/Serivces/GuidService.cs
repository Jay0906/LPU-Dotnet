﻿namespace DIPractice.Serivces
{
    public class GuidService
    {
        public Guid Id { get; set; } = Guid.NewGuid();
    }
}
