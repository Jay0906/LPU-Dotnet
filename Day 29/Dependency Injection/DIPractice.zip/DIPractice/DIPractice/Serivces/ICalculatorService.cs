﻿namespace DIPractice.Serivces
{
    public interface ICalculatorService
    {
        int Add(int a, int b);
    }
}
