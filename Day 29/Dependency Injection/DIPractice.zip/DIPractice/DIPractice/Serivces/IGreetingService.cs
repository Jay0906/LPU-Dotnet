﻿namespace DIPractice.Serivces
{
    public interface IGreetingService
    {
        string GetMessage();
    }
}
