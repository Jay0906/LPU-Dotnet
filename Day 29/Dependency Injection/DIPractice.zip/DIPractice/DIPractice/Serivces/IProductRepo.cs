﻿namespace DIPractice.Serivces
{
    public interface IProductRepo
    {
        string GetProduct();
    }
}
