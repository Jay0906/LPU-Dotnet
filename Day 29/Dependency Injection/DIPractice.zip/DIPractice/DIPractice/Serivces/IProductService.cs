﻿namespace DIPractice.Serivces
{
    public interface IProductService
    {
        string GetProduct();
    }
}
