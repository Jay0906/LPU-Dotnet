﻿namespace DIPractice.Serivces
{
    public class ProductRepo: IProductRepo
    {
        public string GetProduct()
        {
            return "Product Recieved";
        }
    }
}
