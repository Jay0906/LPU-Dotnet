﻿namespace DIPractice.Serivces
{
    public class ProductService : IProductService
    {
        private readonly IProductRepo _repo;
        public ProductService(IProductRepo repo)
        {
            _repo = repo;
        }

        public string GetProduct()
        {
            return _repo.GetProduct();
        }
    }
}
