﻿using HttpAttributePrac.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HttpAttributePrac.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _service;
        public ProductController(IProductService service)
        {
            _service = service;
        }

        [HttpGet]
        public List<Product> Get()
        {
            return _service.GetAll();
        }

        [HttpGet("{Id}")]
        public Product Get(int Id)
        {
            return _service.GetbyId(Id);
        }

        [HttpPost]
        public string Post(Product product)
        {
            _service.Add(product);
            return "Product Added";
        }

        [HttpPut]
        public string Put(int Id,Product product)
        {
            product.Id = Id;
            _service.Update(product);
            return "Product Updated";
        }

        [HttpDelete]
        public string Delete(int Id)
        {
            _service.Delete(Id);
            return $"{Id} Deleted";
        }
    }
}
