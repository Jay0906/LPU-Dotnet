﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HttpAttributePrac.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        [HttpGet]
        public string Get()
        {
            return "All Users";
        }

        [HttpPost]
        public string Post(string s)
        {
            return $"{s} created";
        }
    }
}
