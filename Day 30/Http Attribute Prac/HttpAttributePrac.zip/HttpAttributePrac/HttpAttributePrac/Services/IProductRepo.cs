﻿namespace HttpAttributePrac.Services
{
    public interface IProductRepo
    {
        List<Product> GetAll();
        Product GetbyId(int Id);
        void Add(Product product);
        void Update(Product product);
        void Delete(int id);
    }
}
