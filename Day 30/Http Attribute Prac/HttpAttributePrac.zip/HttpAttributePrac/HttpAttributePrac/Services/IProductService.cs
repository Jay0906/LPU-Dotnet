﻿namespace HttpAttributePrac.Services
{
    public interface IProductService
    {
        List<Product> GetAll();
        Product GetbyId(int Id);
        void Add(Product product);
        void Update(Product prodcut);
        void Delete(int Id);

    }
}
