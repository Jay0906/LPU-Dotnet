﻿namespace HttpAttributePrac.Services
{
    public class ProductRepo : IProductRepo
    {
        private static List<Product> products= new List<Product>
        {
            new Product{Id=101,Name="Ambi",Price=21000},
            new Product{Id=102,Name="Jay",Price=22000},
            new Product{Id=103,Name="Prakash",Price=23000},
            new Product{Id=104,Name="Gera",Price=24000},
            new Product{Id=105,Name="Manju",Price=25000}
        };

        public List<Product> GetAll()
        {
            return products;
        }

        public Product GetbyId(int Id)
        {
            var prod = products.FirstOrDefault(n => n.Id == Id);
            if (prod != null)
            {
                return prod;
            }
            return null;
        }

        public void Add(Product product)
        {
            products.Add(product);
        }

        public void Update(Product product)
        {
            var prod=products.FirstOrDefault(n=>n.Id==product.Id);
            if(prod != null)
            {
                prod.Name=product.Name;
                prod.Price = product.Price;
            }
        }

        public void Delete(int Id)
        {
            var prod = products.FirstOrDefault(n => n.Id == Id);
            if (prod != null)
            {
                products.Remove(prod);
            }
        }
    }
}
