﻿namespace HttpAttributePrac.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepo _repo;
        public ProductService(IProductRepo repo)
        {
            _repo = repo;
        }

        public List<Product> GetAll() => _repo.GetAll();
        public Product GetbyId(int Id) => _repo.GetbyId(Id);
        public void Add(Product product) => _repo.Add(product);
        public void Update(Product product) => _repo.Update(product);
        public void Delete(int Id) => _repo.Delete(Id);
    }
}
